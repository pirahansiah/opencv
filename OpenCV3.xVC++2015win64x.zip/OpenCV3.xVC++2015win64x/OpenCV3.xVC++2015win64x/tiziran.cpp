/*
#include "opencv2/video/video.hpp"
#include "opencv2/videoio.hpp"
#include <opencv2/opencv.hpp>
#include <iostream>
using namespace cv;
using namespace std;
void main(void)
{	
	VideoCapture inputVideo("c:\\FarshidPirahanSiah\\tiziran.avi");
	int framenumbers = inputVideo.get(CAP_PROP_FRAME_COUNT);
	Mat image;	
	for (int i = 0; i < framenumbers; i++)
	{
		inputVideo >> image;
		imshow("video", image);
		cvWaitKey(100);
	}
}
*/